from flask import Flask
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from flask_codemirror import CodeMirror
from runner.util.io import read_config as config_file


def config_from_file(app):
    app.config.from_mapping(config_file())
    app.config['SQLALCHEMY_DATABASE_URI'] = (
        f'mysql+mysqlconnector://{app.config["MYSQL_USER"]}:{app.config["MYSQL_PASS"]}'
        f'@{app.config["MYSQL_SERVER"]}:{app.config["MYSQL_PORT"]}/{app.config["MYSQL_DB"]}')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


def config_app(app):
    app.secret_key = b'f\x88\xc8\xa4o-\x9cRF\x1f\xe6\x18\xd8\x8bW`\xcfN\xe9M\\\xa7$\x98'

    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'


def config_blueprints(app):
    from .auth import auth_bp
    app.register_blueprint(auth_bp)

    from .admin import admin_bp
    app.register_blueprint(admin_bp)

    from .public import public_bp
    app.register_blueprint(public_bp)


login_manager = LoginManager()
db = SQLAlchemy()
codemirror = CodeMirror()


def create_app():
    app = Flask(__name__)

    config_app(app)
    config_from_file(app)
    config_blueprints(app)

    db.init_app(app)
    codemirror.init_app(app)

    return app


def create_app_db_context():
    app = Flask(__name__)

    config_from_file(app)

    db.init_app(app)
    return app


def create_all_db():
    app = Flask(__name__)

    config_from_file(app)

    db.init_app(app)
    with app.app_context():
        db.create_all()
