import json
import os
import time
from datetime import datetime
from os.path import join as path_join

import docker

from runner import create_app_db_context
from runner.models import Run
from runner.util import io
from runner.util.io import get_file_from_tar


# TODO TIMEOUT (SCRIPT OR IN RUN FUNCTION?)

def run_program_worker(run_id):
    app = create_app_db_context()
    with app.app_context():
        run_program(run_id)


def run_program(run_id):
    run = Run.query.get(run_id)

    try:
        print("WORKER START")
        client = docker.from_env()
        run.run_date = datetime.now()
        run.status = 'running'
        run.save()

        # RUN FILES
        program = get_run_file(run.id, run.config_id)
        test = get_test_file(run.config_id)
        script = get_script_file(run.script_id)
        # ENV VARS
        env = {
            'PROGRAM_ZIP': 'program.zip',
            'PROGRAM_ROOT_PATH': run.config.root,
            'PROGRAM_MAIN_PATH': run.config.main
        }

        # DOCKER RUN
        image = build_image(client)
        container = run_container(client, image, env=env)
        container.put_archive('/program/', program)
        container.put_archive('/program/', script)
        container.put_archive('/program/test', test)

        container.exec_run(['chmod', '+x', '/program/script.sh'])
        container.exec_run(['/bin/bash', '/program/script.sh'])
        container.exec_run(
            f'pmd -d ./build/{run.config.root} -R rulesets/java/quickstart.xml -f json -r ./output/analysis')

        # OUTPUT
        bits, stat = get_docker_archive(container, '/program/output/output')
        output_tar_bytes = io.get_bytes(bits)
        output = str(io.get_file_from_tar(output_tar_bytes, 'output'), 'utf-8')
        output = json.loads(output)

        # ANALYSIS
        bits, stat = get_docker_archive(container, '/program/output/analysis')
        analysis_tar_bytes = io.get_bytes(bits)
        analysis = str(io.get_file_from_tar(analysis_tar_bytes, 'analysis'), 'utf-8')
        analysis = json.loads(analysis)
        output['analysis'] = analysis

        stop_container(container)
        remove_container(container)

        run.output = output
        run.status = 'done'
        run.save()

        print('WORKER END')

    except Exception as e:
        print("Run exception: ", e)
        run.status = 'error'
        run.save()

        # if container:
        # stop_container(container)
        # remove_container(container)


def build_image(client):
    image = client.images.build(path=path_join('docker'), rm=True, forcerm=True, tag='programrunner')

    return image


def run_container(client, image, command=[], env={}):
    container = client.containers.run(image[0], command, environment=env, detach=True, tty=True)
    return container


def get_docker_archive(container, archive_path, tries=20):
    while tries > 0:
        try:
            bits, stat = container.get_archive(archive_path)
            return bits, stat
        except docker.errors.APIError:
            tries -= 1
            time.sleep(0.5)


def remove_container(container):
    container.remove()


def stop_container(container):
    container.stop()


# FILE HANDLING
def docker_base_path():
    return 'docker'


def docker_config_base_path():
    path = path_join(docker_base_path(), 'config')
    return path


def docker_scripts_base_path():
    path = path_join(docker_base_path(), 'scripts')
    return path


def config_path(config_id):
    path = path_join(docker_config_base_path(), config_id)
    return path


def config_runs_path(config_id):
    path = path_join(config_path(config_id), 'runs')
    return path


def config_test_path(config_id):
    path = path_join(config_path(config_id), 'test')
    return path


def config_create_dirs(config_id):
    os.mkdir(config_path(config_id))
    os.mkdir(config_test_path(config_id))
    os.mkdir(config_runs_path(config_id))


def script_name(script_id):
    name = script_id + '.tar'
    return name


def script_path(script_id):
    file_path = path_join(docker_scripts_base_path(), script_name(script_id))
    return file_path


def run_file_name(config_id, run_id):
    name = str(config_id) + '_' + str(run_id) + '.tar'
    return name


def run_file_path(run_id, config_id):
    file_path = path_join(config_runs_path(config_id), run_file_name(config_id, run_id))
    return file_path


def run_test_name():
    name = 'test.tar'
    return name


def run_test_path(config_id):
    file_path = path_join(config_test_path(config_id), run_test_name())
    return file_path


def get_run_file(run_id, config_id):
    file_path = run_file_path(run_id, config_id)
    file = io.read_file(file_path)
    file_bytes = file.read()

    return file_bytes


def save_run_file(file, run_id, config_id):
    file_path = run_file_path(run_id, config_id)

    io.write_file(file, file_path)


def get_test_file(config_id):
    file_path = run_test_path(config_id)
    file = io.read_file(file_path)
    file_bytes = file.read()

    return file_bytes


def remove_test_file(config_id):
    file_path = run_test_path(config_id)

    io.remove_file(file_path)


def save_test_file(file, config_id):
    file_path = run_test_path(config_id)

    io.write_file(file, file_path)


def get_script_file(script_id):
    file_path = script_path(script_id)
    file = io.read_file(file_path)
    file_bytes = file.read()

    return file_bytes


def get_script_file_untar(script_id):
    file_path = script_path(script_id)
    file = io.read_file(file_path)
    file = get_file_from_tar(file.read(), 'script.sh')

    return file


def save_script_file(file, script_id):
    file_path = script_path(script_id)

    io.write_file(file, file_path)
