from flask_wtf import FlaskForm
from wtforms import BooleanField, PasswordField, StringField, SubmitField
from wtforms.validators import Email, EqualTo, InputRequired, Length


class SignupForm(FlaskForm):
    name = StringField('Name', validators=[Length(max=32, message='Max length 32'), InputRequired(message='Required')])
    email = StringField('Email', validators=[Length(max=256, message='Max length 256'), Email(),
                                             InputRequired(message='Required')])
    password = PasswordField('Password', validators=[Length(max=128, message='Max length 64'),
                                                     EqualTo('confirm', message='Passwords must match'),
                                                     InputRequired(message='Required')])
    confirm = PasswordField('Repeat password', validators=[InputRequired(message='Required')])
    submit = SubmitField('Register')


class LoginForm(FlaskForm):
    name = StringField('Name', validators=[InputRequired(message='Required')])
    password = PasswordField('Password', validators=[InputRequired(message='Required')])
    remember_me = BooleanField('Rembember me')
    submit = SubmitField('Log in')
