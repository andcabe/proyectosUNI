from flask import redirect, render_template, request, url_for
from flask_login import current_user, login_required, login_user, logout_user
from werkzeug.urls import url_parse

from runner import login_manager
from runner.models import User

from . import auth_bp
from .forms import LoginForm, SignupForm


@login_manager.user_loader
def load_user(user_id):
    return User.get_by_id(user_id)


@auth_bp.route('/signup', methods=['GET', 'POST'])
def sign_up():
    if current_user.is_authenticated:
        return redirect(url_for('public.index'))
    form = SignupForm()
    if form.validate_on_submit():
        id = form.name.data
        email = form.email.data
        password = form.password.data

        if User.get_by_id(id) is None:
            user = User(id=id, email=email)
            user.set_password(password)
            user.save()
            login_user(user, remember=True)
            next_page = request.args.get('next', None)
            if not next_page or url_parse(next_page).netloc != '':
                next_page = url_for('public.index')
            return redirect(next_page)
        else:
            form.name.errors.append('Username already exists')
    return render_template("signup.html", form=form)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('public.index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.get_by_id(form.name.data)
        if user is not None and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            next_page = request.args.get('next')
            if not next_page or url_parse(next_page).netloc != '':
                next_page = url_for('public.index')
            return redirect(next_page)
        else:
            form.name.errors.append('User or password are incorrect')
    return render_template('login.html', form=form)


@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('public.index'))
