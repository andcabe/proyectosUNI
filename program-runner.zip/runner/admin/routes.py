import os
import tarfile
from functools import wraps
from io import BytesIO

from flask import abort, jsonify, redirect, render_template, send_file, url_for
from flask_login import current_user, login_required, logout_user

from runner.models import Config, ConfigScript, Run, Script, User
from runner.run import (config_create_dirs, config_path, get_script_file,
                        get_test_file, run_file_path, save_script_file,
                        save_test_file, script_path)
from runner.util import io

from . import admin_bp
from .forms import ConfigForm, InputForm, ScriptForm, TestForm


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kws):
        if not current_user.admin:
            abort(401)
        return f(*args, **kws)

    return decorated_function


'''
    NEW CONFIG VIEW
'''


@admin_bp.route('/config/new', methods=['GET', 'POST'])
@login_required
@admin_required
def config_new():
    #TODO TAR INPUT LOGIC (READ TAR, VALIDATE, GET TEST STRUCTURE JSON)
    form = ConfigForm()
    form.set_script_context()
    form.tests.set_type(form.tests.type_input.data or 'manual')
    if form.tests.type_input.data == 'manual' and form.validate_on_submit():
        id = form.id.data
        description = form.description.data
        script = form.script.data
        root = form.root.data if form.root.data else './'
        main = form.main.data
        tests = form.tests.manual

        tests_json = config_new_tests_json(tests)

        config = Config(id=id, description=description, root=root, main=main, tests=tests_json)
        config.save()

        [ConfigScript(config_id=config.id, script_id=s).save() for s in script]

        tests_tar_file = config_new_tests_tar(tests)
        config_create_dirs(config.id)
        save_test_file(tests_tar_file, config.id)

        return redirect(url_for('public.config_list'))

    return render_template('config/new_config.html', form=form)


def config_new_tests_json(tests):
    tests_dict = [{'output': test.output.data.filename,
                   'inputs': [{'type': inp.type_input.data,
                               'text': inp.get_json_data_by_type()}
                              for inp in test.inputs]}
                  for test in tests]

    return tests_dict


def config_new_tests_tar(tests):
    join = os.path.join
    tar = tarfile.open(fileobj=BytesIO(), mode='w')

    for idx, test in enumerate(tests):
        test_name = 'test' + str(idx).zfill(3)
        io.add_dir_to_tar(tar, test_name)

        io.add_dir_to_tar(tar, join(test_name, 'output'))

        io.add_file_to_tar(tar, join(test_name, 'output', 'expected'), test.output.data.read())

        io.add_dir_to_tar(tar, join(test_name, 'input'))
        io.add_dir_to_tar(tar, join(test_name, 'input', 'data'))

        input_file = ''
        for inp in test.inputs:
            if inp.type_input.data == 'file':
                input_file = input_file + "<file::" + inp.file.data.filename + "\n"
                io.add_file_to_tar(tar, join(test_name, 'input', 'data', inp.file.data.filename),
                                   inp.file.data.read())
            if inp.type_input.data == 'text':
                input_file = input_file + inp.text.data + "\n"

        io.add_file_to_tar(tar, join(test_name, 'input', 'input'), bytes(input_file, 'utf-8'))

    return tar.fileobj.getvalue()


@admin_bp.route('/config/new/add/test', methods=['GET'])
@login_required
@admin_required
def config_new_add_test():
    form = TestForm()
    form.output.render_kw = {'class': 'form-control'}
    form_dict = {'hidden_tag': str(form.hidden_tag()), 'output': str(form.output),
                 'output_label': str(form.output.label)}
    return jsonify(form_dict)


@admin_bp.route('/config/new/add/input/<type_input>', methods=['GET'])
@login_required
@admin_required
def config_new_add_input(type_input):
    form = InputForm()
    form.set_type(type_input)

    form_input = form.get_by_type()

    form_input.render_kw = {'class': 'form-control'}
    form_dict = {'hidden_tag': str(form.hidden_tag()), 'input': str(form_input),
                 'input_label': str(form_input.label), 'type_input': str(form.type_input)}

    return jsonify(form_dict)


'''
    RUN LIST VIEW
'''


@admin_bp.route('/run/list/remove/<run_id>', methods=['GET'])
@login_required
@admin_required
def run_list_remove_run(run_id):
    run = Run.get_by_id(run_id)
    if run:
        file_path = run_file_path(run, run.config_id)
        io.remove_file(file_path)
        run.remove()

    return redirect(url_for('public.run_list'))


'''
    CONFIG LIST VIEW
'''


@admin_bp.route('/config/list/remove/<config_id>', methods=['GET'])
@login_required
@admin_required
def config_list_remove_config(config_id):
    config = Config.get_by_id(config_id)
    if config:
        file_path = config_path(config_id)
        io.remove_dir(file_path)

        config.remove()

    return redirect(url_for('public.config_list'))


@admin_bp.route('/config/list/download/<config_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def config_list_download_tests(config_id):
    config = Config.get_by_id(config_id)

    if not config:
        abort(404)

    file = get_test_file(config.id)
    return send_file(io.io.BytesIO(file), as_attachment=True, attachment_filename=f'tests_{config_id}.tar')


'''
    SCRIPT LIST VIEW
'''


@admin_bp.route('/script/list/remove/<script_id>', methods=['GET'])
@login_required
@admin_required
def script_list_remove_script(script_id):
    script = Script.get_by_id(script_id)
    if script:
        file_path = script_path(script_id)
        io.remove_file(file_path)

        script.remove()

    return redirect(url_for('public.script_list'))


@admin_bp.route('/script/list/download/<script_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def script_list_download_script(script_id):
    script = Script.get_by_id(script_id)

    if not script:
        abort(404)

    file = get_script_file(script_id)
    return send_file(io.io.BytesIO(file), as_attachment=True, attachment_filename=f'{script_id}.tar')


'''
    NEW SCRIPT VIEW   
'''


@admin_bp.route('/script/new', methods=['GET', 'POST'])
@login_required
@admin_required
def script_new():
    form = ScriptForm()
    form.script.set_type(form.script.type_input.data or 'file')
    if form.validate_on_submit():
        id = form.id.data
        language = form.language.data
        description = form.description.data

        if Script.get_by_id(id):
            form.id.errors.append('Script already exists')
            return render_template('script/new_script.html', form=form)

        script = Script(id=id, language=language, description=description)
        script.save()

        save_script_tar(form.script, id, 'script.sh')

        return redirect(url_for('public.script_list'))

    return render_template('script/new_script.html', form=form)


def save_script_tar(form, tar_name, script_name):
    if form.type_input.data == 'code':
        file = form.code.data
        file = '\n'.join(file.splitlines())
        file_bytes = bytes(file, 'utf-8')
    else:
        file = form.file.data
        file_bytes = file.read()

    script_tar = io.create_tar_file(file_bytes, script_name)
    save_script_file(script_tar, tar_name)


'''
    USER LIST VIEW
'''


@admin_bp.route('/user/list', methods=['GET'])
@login_required
@admin_required
def user_list():
    users = User.get_all_sorted()

    return render_template('user/user_list.html', users=users)


@admin_bp.route('/user/list/remove/<user_id>', methods=['GET'])
@login_required
@admin_required
def user_list_remove_user(user_id):
    user = User.get_by_id(user_id)
    if user:
        if user.id == current_user.id:
            logout_user()
        user.remove()

    return redirect(url_for('admin.user_list'))

