from flask_codemirror.fields import CodeMirrorField
from flask_wtf import FlaskForm
from flask_wtf.file import FileRequired, FileAllowed
from wtforms import (FieldList, FileField, FormField, HiddenField, RadioField,
                     SelectMultipleField, StringField, SubmitField,
                     TextAreaField)
from wtforms.validators import InputRequired, Length, Regexp

from runner.models import Config, Script


class InputForm(FlaskForm):
    file = FileField('File INPUT:', render_kw={'required': True})
    text = StringField('Text INPUT:', render_kw={'required': True})
    type_input = HiddenField()
    validators = {
        'text': (text, [Length(max=256, message='Max length 256 characters'),
                              InputRequired('Input text is required!')]),
        'file': (file, [FileRequired(message='Input file is required!')])
    }

    def validate_file(self, file):
        if self.type_input.data == 'file':
            return self.file.validate(InputForm, self.validators['file'][1])
        return True

    def validate_text(self, text):
        if self.type_input.data == 'text':
            return self.text.validate(InputForm, self.validators['text'][1])
        return True

    def set_type(self, type_input):
        self.type_input.data = type_input

    def get_by_type(self):
        if self.type_input.data == 'file':
            return self.file
        elif self.type_input.data == 'text':
            return self.text
        else:
            return None

    def get_json_data_by_type(self):
        if self.type_input.data == 'file':
            return self.file.data.filename
        elif self.type_input.data == 'text':
            return self.text.data
        else:
            return None


class TestForm(FlaskForm):
    output = FileField('Expected OUTPUT:', validators=[FileRequired(message='Output file is required!')])
    inputs = FieldList(FormField(InputForm), min_entries=0)


class ManualOrTarForm(FlaskForm):
    type_input = RadioField('Input type:', choices=[('tar', 'Tar input'), ('manual', 'Manual input')])
    tar = FileField('TAR file:', render_kw={'required': True})
    manual = FieldList(FormField(TestForm), min_entries=1)

    validators = {
        'tar': (tar, [FileRequired(message='Output file is required!'),
                      FileAllowed(upload_set=['tar'], message='Must be a tar file!')]),
        'manual': (manual, [])
    }

    def validate_tar(self, tar):
        if self.type_input.data == 'tar':
            return self.tar.validate(TestForm, self.validators['tar'][1])
        return True

    def validate_manual(self, manual):
        if self.type_input.data != 'manual':
            self.manual.errors = []
        return True

    def set_type(self, type):
        self.validators[type][0].render_kw = {'disabled': True}

        self.type_input.default = type
        self.type_input.data = type

    def get_by_type(self):
        if self.type_input.data == 'tar':
            return self.tar
        elif self.type_input.data == 'manual':
            return self.manual
        else:
            return None

    def get_json_data_by_type(self):
        if self.type_input.data == 'tar':
            return self.tar.data.filename
        elif self.type_input.data == 'manual':
            return self.manual.data
        else:
            return None


class ConfigForm(FlaskForm):
    id = StringField('Name (ID)',
                     validators=[Length(max=32, message='Max length 32 characters'), InputRequired(message='Required'),
                                 Regexp(r'^[\w]', message='Invalid config name (must start with alphanumeric)')])
    description = TextAreaField('Description', validators=[Length(max=65535, message='Max length 64KB'),
                                                           InputRequired(message='Required')])
    script = SelectMultipleField('Configuration script:',
                                 validators=[InputRequired(message='Configuration script is required!')])
    root = StringField('Root path', validators=[Length(max=256, message='Max length 256 characters')])
    main = StringField('Main path', validators=[Length(max=256, message='Max length 256 characters'),
                                                InputRequired(message='Required')])

    tests = FormField(ManualOrTarForm)

    submit = SubmitField('Add Configuration')

    def set_script_context(self):
        scripts = Script.query.all()
        self.script.choices = [(s.id, s.id + ' (' + s.language + ')') for s in scripts]

    def validate_id(self, message="Config already exists"):
        if self.id.data and Config.query.get(self.id.data):
            self.id.errors.append(message)
            return False
        return True


class EditConfigTestsForm(FlaskForm):
    tests = FormField(ManualOrTarForm)
    submit_config_tests = SubmitField('Set')


class ScriptCodeForm(FlaskForm):
    type_input = RadioField('Input type:', choices=[('file', 'File input'), ('code', 'Code input')])
    file = FileField('Script:')
    code = CodeMirrorField('Script:', language='shell', config={'lineNumbers': 'true'})

    validators = {
        'file': (file, [FileRequired(message='Script file is required!')]),
        'code': (code, [InputRequired(message='Input code is required!')])
    }

    def validate_file(self, file):
        if self.type_input.data == 'file':
            return self.file.validate(ScriptCodeForm, self.validators['file'][1])
        return True

    def validate_code(self, code):
        if self.type_input.data == 'code':
            return self.code.validate(ScriptCodeForm, self.validators['code'][1])
        return True

    def set_type(self, type):
        self.validators[type][0].render_kw = {'disabled': True}

        self.type_input.default = type
        self.type_input.data = type

    def get_by_type(self):
        if self.type_input.data == 'file':
            return self.file
        elif self.type_input.data == 'code':
            return self.code
        else:
            return None

    def get_json_data_by_type(self):
        if self.type_input.data == 'file':
            return self.file.data.filename
        elif self.type_input.data == 'code':
            return self.code.data
        else:
            return None


class ScriptForm(FlaskForm):
    id = StringField('Name (ID)', validators=[Length(max=32, message='Max length 32 characters'),
                                              Regexp(r'^[\w]',
                                                     message='Invalid config name (must start with alphanumeric)'),
                                              InputRequired(message='Required')])

    language = StringField('Language', validators=[Length(max=32, message='Max length 32 characters'),
                                                   InputRequired(message='Required')])

    description = TextAreaField('Description', validators=[Length(max=65535, message='Max length 64KB'),
                                                           InputRequired(message='Required')])

    script = FormField(ScriptCodeForm, separator='_')

    submit = SubmitField('Add Submit')


class ScriptEditCodeForm(FlaskForm):
    script = FormField(ScriptCodeForm, separator='_')
    submit_script_edit_code = SubmitField('Set')


class ScriptEditForm(FlaskForm):
    language = StringField('Language', validators=[Length(max=32, message='Max length 32 characters'),
                                                   InputRequired(message='Required')])

    description = TextAreaField('Description', validators=[Length(max=65535, message='Max length 64KB'),
                                                           InputRequired(message='Required')])
    submit_script_edit = SubmitField('Set')
