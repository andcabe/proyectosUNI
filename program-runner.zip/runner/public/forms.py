from flask_login import current_user
from flask_wtf import FlaskForm
from flask_wtf.file import FileAllowed, FileRequired
from wtforms import (BooleanField, FileField, PasswordField, SelectField,
                     SelectMultipleField, StringField, SubmitField, TextAreaField)
from wtforms.validators import Email, EqualTo, InputRequired, Length, Regexp

from runner.models import Config, Script, User


class NewRunForm(FlaskForm):
    name = StringField('Name:', validators=[InputRequired(message='Run name is required!')])
    program = FileField('Program:', validators=[FileRequired(message='Run file is required!'),
                                                FileAllowed(upload_set=['zip'], message='Must be a zip file!')])
    config = SelectField('Run configuration:', coerce=str,
                         validators=[InputRequired(message='Run configuration is required!')])
    script = SelectField('Configuration script:', coerce=str,
                         validators=[InputRequired(message='Configuration script is required!')])
    submit = SubmitField('Run')

    def set_config_context(self):
        if current_user.admin:
            configs = Config.query.all()
        else:
            configs = Config.get_by_user(current_user.id)

        self.config.choices = [c.id for c in configs]

    def set_script_context(self, config_id):
        if config_id not in self.config.choices:
            self.script.choices = []
            return

        scripts = Script.get_by_config(config_id)
        self.script.choices = [s.id for s in scripts]


class UserProfilePasswordForm(FlaskForm):
    current = PasswordField('Current password', validators=[Length(max=128, message='Max length 64')])
    password = PasswordField('New password', validators=[Length(max=128, message='Max length 64'),
                                                         EqualTo('confirm', message='Passwords must match'),
                                                         InputRequired(message='Required')])
    confirm = PasswordField('Repeat new password', validators=[InputRequired(message='Required')])
    user_id = ''
    submit_user_profile_password = SubmitField('Change')

    def validate_current(self, current):
        if current_user.admin:
            return True

        if not User.get_by_id(self.user_id).check_password(current.data):
            self.current.errors = ['Wrong current password!']
            return False
        return True


class UserProfileEmailForm(FlaskForm):
    email = StringField('New email', validators=[Length(max=256, message='Max length 256'), Email(),
                                                 InputRequired(message='Required')])
    submit_user_profile_email = SubmitField('Change')


class UserProfileAdminForm(FlaskForm):
    admin = BooleanField('Set as admin')
    submit_user_profile_admin = SubmitField('Set')


class UserProfileConfigForm(FlaskForm):
    configs = SelectMultipleField('Allowed Configurations:')
    submit_user_profile_config = SubmitField('Set')


class ConfigProfileEditForm(FlaskForm):

    description = TextAreaField('Description', validators=[Length(max=65535, message='Max length 64KB'),
                                                           InputRequired(message='Required')])
    root = StringField('Root path', validators=[Length(max=256, message='Max length 256 characters')])
    main = StringField('Main path', validators=[Length(max=256, message='Max length 256 characters'),
                                                InputRequired(message='Required')])
    submit_config_profile_edit = SubmitField('Set')


class ConfigProfileScriptForm(FlaskForm):
    scripts = SelectMultipleField('Allowed Scripts')
    submit_config_profile_script = SubmitField('Set')


class ConfigProfileUserForm(FlaskForm):
    users = SelectMultipleField('Allowed Users')
    submit_config_profile_user = SubmitField('Set')


class ScriptProfileConfigForm(FlaskForm):
    configs = SelectMultipleField('Configurations allowed:')
    submit_script_profile_config = SubmitField('Set')
