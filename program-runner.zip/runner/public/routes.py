from datetime import datetime

from flask import (abort, current_app, jsonify, render_template, request,
                   send_file, url_for)
from flask_login import current_user, login_required
from rq import Queue
from werkzeug.utils import redirect

from runner.models import Config, Run, Script, User, UserConfig, ConfigScript
from runner.public import public_bp
from runner.run import (get_run_file, run_program, run_program_worker,
                        save_run_file, save_test_file, remove_test_file, get_script_file_untar)
from runner.util import io
from worker import conn

from .forms import (NewRunForm, UserProfileAdminForm, UserProfileConfigForm,
                    UserProfileEmailForm, UserProfilePasswordForm, ConfigProfileScriptForm, ConfigProfileUserForm,
                    ScriptProfileConfigForm, ConfigProfileEditForm)
from runner.admin.forms import EditConfigTestsForm, ScriptEditCodeForm, ScriptEditForm
from runner.admin.routes import config_new_tests_json, config_new_tests_tar, save_script_tar

q = Queue(connection=conn)

'''
   TODO ERROR PAGES
'''


@public_bp.route('/', methods=['GET'])
@login_required
def index():
    return redirect(url_for('public.run_list'))


'''
    RUN
'''


@public_bp.route('/run/list', methods=['GET'])
@login_required
def run_list():
    if current_user.admin:
        runs = Run.get_all_sorted()
    else:
        runs = Run.get_by_user_sorted(current_user.id)

    return render_template('run/run_list.html', runs=runs)


@public_bp.route('/run/list/run/<run_id>', methods=['GET'])
@login_required
def run_list_run(run_id):
    run = Run.query.get(run_id)

    if not run:
        return jsonify({})

    if current_user.admin:
        return jsonify(run.as_dict_nest())
    elif run.user_id == current_user.id:
        return jsonify(run.as_dict_nest())

    return jsonify({})


@public_bp.route('/run/list/run/download/<run_id>', methods=['GET', 'POST'])
@login_required
def run_list_download_run(run_id):
    run = Run.query.get(run_id)

    if not run:
        abort(404)

    if current_user.admin:
        file = get_run_file(run.id, run.config_id)
    elif run.user_id == current_user.id:
        file = get_run_file(run.id, run.config_id)
    else:
        abort(403)

    file = io.get_file_from_tar(file, 'program.zip')

    return send_file(io.io.BytesIO(file), as_attachment=True, attachment_filename=run.filename)


@public_bp.route('/run/new', methods=['GET', 'POST'])
@login_required
def run_new():
    form = NewRunForm()
    config_id = form.config.data if form.config.data is not None else ''
    form.set_config_context()
    form.set_script_context(config_id)
    if form.validate_on_submit():
        name = form.name.data
        program = form.program.data
        config = Config.query.get(form.config.data)
        script = Script.query.get(form.script.data)

        run = Run(name=name, filename=program.filename, config_id=config.id, script_id=script.id,
                  user_id=current_user.id,
                  status='queued', added_date=datetime.now())
        run.save()

        run_file = run_new_tar_file(program)
        save_run_file(run_file, run.id, run.config_id)

        if current_app.config['DOCKER']:
            q.enqueue(run_program_worker, args=(run.id,))
        else:
            run_program(run.id)

        return redirect(url_for('public.run_list'))

    if not form.config.choices:
        form.config.render_kw = {'disabled': True}
        form.script.render_kw = {'disabled': True}
        return render_template('run/new_run.html', form=form)

    scripts = Script.get_by_config(form.config.choices[0])
    form.script.choices = [s.id for s in scripts]

    if not scripts:
        form.script.render_kw = {'disabled': True}
        return render_template('run/new_run.html', form=form)

    return render_template('run/new_run.html', form=form)


def run_new_tar_file(program):
    file_bytes = program.read()
    tar_file = io.create_tar_file(file_bytes, 'program.zip')

    return tar_file


@public_bp.route('/run/profile/<run_id>', methods=['GET', 'POST'])
@login_required
def run_profile(run_id):
    run = Run.get_by_id(run_id)

    if not run:
        abort(404)

    if current_user.admin or run.user_id == current_user.id:

        return render_template('run/run.html', run=run)

    abort(403)



@public_bp.route('/run/new/<config_id>', methods=['GET'])
@login_required
def run_new_change_config(config_id):
    select = NewRunForm().script
    select.render_kw = {'disabled': True}

    scripts = Script.get_by_config(config_id)

    if UserConfig.query.get((current_user.id, config_id)) is None and not current_user.admin or not scripts:
        return jsonify({'select': str(select)})

    select = NewRunForm().script
    select.choices = [s.id for s in scripts]

    select.render_kw = {}

    return jsonify({'select': str(select)})


'''
    CONFIG
'''


@public_bp.route('/config/list', methods=['GET'])
@login_required
def config_list():
    if current_user.admin:
        configs = Config.get_all_sorted()
    else:
        configs = Config.get_by_user_sorted(current_user.id)

    return render_template('config/config_list.html', configs=configs)


@public_bp.route('/config/list/<config_id>', methods=['GET'])
@login_required
def config_list_config(config_id):
    config = Config.query.get(config_id)

    if not config:
        return jsonify({})

    if current_user.admin:
        return jsonify(config.as_dict_nest())
    elif UserConfig.query.get((current_user.id, config_id)):
        config_json = config.as_dict_nest()

        runs = []
        for run in config_json['runs']:
            if run['user_id'] == current_user.id:
                runs.append(run)

        config_json['runs'] = runs
        config_json['user_association'] = [UserConfig.query.get((current_user.id, config_id)).as_dict()]

        return jsonify(config_json)

    return jsonify({})


@public_bp.route('/config/profile/<config_id>', methods=['GET', 'POST'])
@login_required
def config_profile(config_id):
    config = Config.get_by_id(config_id)

    if not config:
        abort(404)

    if current_user.admin or UserConfig.query.get((current_user.id, config.id)):

        edit_form = ConfigProfileEditForm()
        if request.form.get('submit_config_profile_edit') and edit_form.validate_on_submit() and current_user.admin:
            description = edit_form.description.data
            root = edit_form.root.data if edit_form.root.data else './'
            main = edit_form.main.data

            config.description = description
            config.root = root
            config.main = main
            config.save()

        edit_form.description.data = config.description
        edit_form.root.data = config.root
        edit_form.main.data = config.main

        test_form = EditConfigTestsForm()
        test_form.tests.set_type(test_form.tests.type_input.data or 'manual')
        if request.form.get('submit_config_tests') and test_form.tests.type_input.data == 'manual' and test_form.validate_on_submit() and current_user.admin:
            tests = test_form.tests.manual

            tests_json = config_new_tests_json(tests)

            config.tests = tests_json
            config.save()

            tests_tar_file = config_new_tests_tar(tests)
            remove_test_file(config.id)
            save_test_file(tests_tar_file, config.id)

        script_form = ConfigProfileScriptForm()
        script_form.scripts.choices = [(script.id, script.id) for script in Script.get_all_sorted()]
        if request.form.get('submit_config_profile_script') and script_form.validate_on_submit() and current_user.admin:
            scripts = script_form.scripts.data

            for config_script in config.script_association:
                config_script.remove()

            for script_id in scripts:
                ConfigScript(script_id=script_id, config_id=config_id).save()

        script_form.scripts.default = [sa.script.id for sa in config.script_association]
        script_form.process()

        user_form = ConfigProfileUserForm()
        user_form.users.choices = [(user.id, user.id) for user in User.get_all_sorted()]
        if request.form.get('submit_config_profile_user') and user_form.validate_on_submit() and current_user.admin:
            users = user_form.users.data

            for user_config in config.user_association:
                user_config.remove()

            for user_id in users:
                UserConfig(user_id=user_id, config_id=config_id).save()

        user_form.users.default = [ua.user.id for ua in config.user_association]
        user_form.process()

        return render_template('config/config.html', config=config, test_form=test_form, script_form=script_form, user_form=user_form, edit_form=edit_form)

    abort(403)


'''
    SCRIPT
'''


@public_bp.route('/script/list', methods=['GET'])
@login_required
def script_list():
    scripts = Script.get_all_sorted()

    return render_template('script/script_list.html', scripts=scripts)


@public_bp.route('/script/list/<script_id>', methods=['GET'])
@login_required
def script_list_script(script_id):
    script = Script.get_by_id(script_id)

    if not script:
        return jsonify({})

    if current_user.admin:
        return jsonify(script.as_dict_nest())
    else:
        script_json = script.as_dict_nest()

        runs = []
        for run in script_json['runs']:
            if run['user_id'] == current_user.id:
                runs.append(run)

        configs = []
        for cs in script_json['config_association']:
            if UserConfig.query.get((current_user.id, cs['config']['id'])):
                configs.append(cs)

        script_json['runs'] = runs
        script_json['config_association'] = configs

        return jsonify(script_json)

    return jsonify({})


@public_bp.route('/script/profile/<script_id>', methods=['GET', 'POST'])
@login_required
def script_profile(script_id):
    script = Script.get_by_id(script_id)

    if not script:
        abort(404)

    edit_form = ScriptEditForm()
    if request.form.get('submit_script_edit') and edit_form.validate_on_submit() and current_user.admin:
        language = edit_form.language.data
        description = edit_form.description.data

        script.language = language
        script.description = description
        script.save()

    edit_form.language.data = script.language
    edit_form.description.data = script.description

    code_form = ScriptEditCodeForm()
    code_form.script.set_type(code_form.script.type_input.data or 'file')
    if request.form.get('submit_script_edit_code') and code_form.validate_on_submit() and current_user.admin:

        script.save()

        save_script_tar(code_form.script, script.id, 'script.sh')

    code_form.script.code.data = str(get_script_file_untar(script_id), 'utf-8')

    config_form = ScriptProfileConfigForm()
    config_form.configs.choices = [(config.id, config.id) for config in Config.get_all_sorted()]
    if request.form.get('submit_script_profile_config') and config_form.validate_on_submit() and current_user.admin:
        configs = config_form.configs.data

        for config_script in script.config_association:
            config_script.remove()

        for config_id in configs:
            ConfigScript(script_id=script.id, config_id=config_id).save()

    config_form.configs.default = [ca.config.id for ca in script.config_association]
    config_form.process()

    return render_template('script/script.html', script=script, code_form=code_form, config_form=config_form, edit_form=edit_form)

    abort(403)

'''
    USER
'''


@public_bp.route('/user/list/<user_id>', methods=['GET'])
@login_required
def user_list_user(user_id):
    user = User.get_by_id(user_id)

    if not user:
        return jsonify({})

    if current_user.admin:
        return jsonify(user.as_dict_nest())
    elif current_user.id == user_id:
        return jsonify(user.as_dict_nest())

    return jsonify({})


@public_bp.route('/user/profile/<user_id>', methods=['GET', 'POST'])
@login_required
def user_profile(user_id):
    user = User.get_by_id(user_id)

    if not user:
        abort(404)

    if current_user.admin or user.id == current_user.id:
        password_form = UserProfilePasswordForm()
        password_form.user_id = user_id
        if request.form.get('submit_user_profile_password') and password_form.validate_on_submit() and current_user.admin:
            password = password_form.password.data
            user.set_password(password)
            user.save()

        email_form = UserProfileEmailForm()
        if request.form.get('submit_user_profile_email') and email_form.validate_on_submit() and current_user.admin:
            email = email_form.email.data
            user.email = email
            user.save()
        email_form.email.data = user.email

        admin_form = UserProfileAdminForm()
        if request.form.get('submit_user_profile_admin') and admin_form.validate_on_submit() and current_user.admin:
            admin = admin_form.admin.data
            user.admin = admin
            user.save()
        admin_form.admin.data = user.admin

        config_form = UserProfileConfigForm()
        config_form.configs.choices = [(config.id, config.id) for config in Config.get_all_sorted()]
        if request.form.get('submit_user_profile_config') and config_form.validate_on_submit() and current_user.admin:
            configs = config_form.configs.data

            for user_config in user.config_association:
                user_config.remove()

            for config_id in configs:
                UserConfig(user_id=user_id, config_id=config_id).save()

        config_form.configs.default = [ca.config.id for ca in user.config_association]
        config_form.process()

        return render_template('user/user.html', user=user, password_form=password_form, email_form=email_form, admin_form=admin_form, config_form=config_form)

    abort(403)
