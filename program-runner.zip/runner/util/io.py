import shutil
import time

import yaml
import tarfile
from zipfile import ZipFile

import io
import os


def read_config(path='data/config.yml'):
    with open(path) as file:
        config = yaml.load(file, Loader=yaml.FullLoader)
        return config


def read_file(path):
    f = open(path, 'rb')
    return f


def write_file(bits, path):
    f = open(path, 'wb')
    f.write(bits)
    f.close()


def remove_file(path):
    if os.path.exists(path):
        os.remove(path)


def remove_dir(path):
    if os.path.exists(path):
        shutil.rmtree(path)


def get_bytes(bytes_generator):
    bits = b''
    for chunk in bytes_generator:
        bits += chunk
    return bits


def create_tar_file(file_bytes, file_name):
    with tarfile.open(fileobj=io.BytesIO(), mode='w') as tar:
        info = tarfile.TarInfo(file_name)
        info.size = len(file_bytes)

        file_data = io.BytesIO(file_bytes)
        tar.addfile(info, file_data)
        return tar.fileobj.getvalue()


def get_file_from_tar(tar_bytes: bytes, file_in_tar: str) -> bytes:
    tar = tarfile.open(fileobj=io.BytesIO(tar_bytes))
    file = tar.extractfile(tar.getmember(file_in_tar)).read()

    return file


def add_file_to_tar(tar, name, file_bytes):
    info = tarfile.TarInfo(name=name)
    info.size = len(file_bytes)
    info.mtime = time.time()

    file_data = io.BytesIO(file_bytes)
    tar.addfile(info, file_data)

    return tar


def add_dir_to_tar(tar, name):
    info = tarfile.TarInfo(name=name)
    info.type = tarfile.DIRTYPE
    info.mode = 0o755
    info.mtime = time.time()

    tar.addfile(info)

    return tar


def unzip(filepath, folder):
    with ZipFile(filepath, 'r') as zipfile:
        zipfile.extractall(folder)
