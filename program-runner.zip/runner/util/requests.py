from runner.util import io
from flask import abort
from werkzeug.utils import secure_filename

sv_config = io.read_config()


def validate_request(params, args):
    for arg in args:
        if arg not in params:
            abort(400)

        if arg is None:
            abort(400)


def join_params(dict_list):
    final_dict = {}
    for d in dict_list:
        for k in d:
            final_dict[k] = d[k]

    return final_dict


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in sv_config['ALLOWED_EXTENSIONS']


def validate_file(file):
    if file.filename == '':
        abort(400)

    if not allowed_file(file.filename):
        abort(400)


def validate_filename(filename):
    name = secure_filename(filename)
    if name == '':
        abort(400)

    return name
