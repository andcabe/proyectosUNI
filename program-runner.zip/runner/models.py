from flask_login import UserMixin
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship
from werkzeug.security import check_password_hash, generate_password_hash

from runner import db


class User(db.Model, UserMixin):
    __tablename__ = 'user'

    id = db.Column(db.String(32), primary_key=True)

    email = db.Column(db.String(256), nullable=False)

    password = db.Column(db.String(128), nullable=False)

    admin = db.Column(db.Boolean, default=False)

    # runs

    # config_association

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)

    def save(self):
        db.session.add(self)
        db.session.commit()

    def remove(self):
        db.session.delete(self)
        db.session.commit()

    def as_dict(self):
        d = {'id': self.id,
             'email': self.email,
             'password': self.password,
             'admin': self.admin,
             }

        return d

    def as_dict_nest(self):
        d = self.as_dict()
        d['runs'] = [run.as_dict() for run in self.runs]
        d['config_association'] = [user_config.as_dict() for user_config in self.config_association]

        return d

    @staticmethod
    def get_by_id(user_id):
        return User.query.get(user_id)

    @staticmethod
    def get_all_sorted():
        return User.query.filter().order_by(User.id).all()

    def __repr__(self):
        return '<User {}>'.format(self.email)


class Config(db.Model):
    __tablename__ = 'config'

    id = db.Column(db.String(32), primary_key=True)

    description = db.Column(db.TEXT(), nullable=False)

    root = db.Column(db.String(256), nullable=False)

    main = db.Column(db.String(256), nullable=False)

    tests = db.Column(db.JSON(), nullable=False)

    # runs

    # user_association

    # script_association

    def save(self):
        db.session.add(self)
        db.session.commit()

    def remove(self):
        db.session.delete(self)
        db.session.commit()

    def as_dict(self):
        d = {'id': self.id,
             'description': self.description,
             'root': self.root,
             'main': self.main,
             'tests': self.tests,
             }
        return d

    def as_dict_nest(self):
        d = self.as_dict()
        d['runs'] = [run.as_dict() for run in self.runs]
        d['user_association'] = [user_config.as_dict() for user_config in self.user_association]
        d['script_association'] = [config_script.as_dict() for config_script in self.script_association]

        return d

    @staticmethod
    def get_by_id(config_id):
        return Config.query.get(config_id)

    @staticmethod
    def get_by_user(user_id):
        query = Config.query.join(UserConfig).join(User).filter((UserConfig.user_id == user_id)).all()
        return query

    @staticmethod
    def get_all_sorted():
        return Config.query.filter().order_by(Config.id).all()

    @staticmethod
    def get_by_user_sorted(user_id):
        q = Config.query.join(UserConfig).join(User).filter((UserConfig.user_id == user_id)).order_by(Config.id).all()
        return q

    @staticmethod
    def remove_by_id(config_id):
        Config.query.filter(Config.id == config_id).delete()
        db.session.commit()

    def __repr__(self):
        return '<Config {}>'.format(self.id)


class UserConfig(db.Model):
    __tablename__ = 'user_config'

    user_id = db.Column(db.String(32), ForeignKey('user.id'), primary_key=True)
    user = relationship('User', backref=db.backref('config_association', cascade="all,delete", uselist=True))

    config_id = db.Column(db.String(32), ForeignKey('config.id'), primary_key=True)
    config = relationship('Config', backref=db.backref('user_association', cascade="all,delete", uselist=True))

    def __repr__(self):
        return '<UserConfig {},{}>'.format(self.user_id, self.config_id)

    def save(self):
        db.session.add(self)
        db.session.commit()

    def remove(self):
        db.session.delete(self)
        db.session.commit()

    def as_dict(self):
        d = {'user': self.user.as_dict(),
             'config': self.config.as_dict(),
             }
        return d


class Script(db.Model):
    __tablename__ = 'script'

    id = db.Column(db.String(32), primary_key=True)

    language = db.Column(db.String(32), nullable=False)

    description = db.Column(db.TEXT(), nullable=False)

    # runs

    # config_association

    def __repr__(self):
        return '<Script {}>'.format(self.id)

    def save(self):
        db.session.add(self)
        db.session.commit()

    def remove(self):
        db.session.delete(self)
        db.session.commit()

    def as_dict(self):
        d = {'id': self.id,
             'language': self.language,
             'description': self.description}
        return d

    def as_dict_nest(self):
        d = self.as_dict()
        d['runs'] = [run.as_dict() for run in self.runs]
        d['config_association'] = [config_script.as_dict() for config_script in self.config_association]

        return d

    @staticmethod
    def get_by_id(script_id):
        return Script.query.get(script_id)

    @staticmethod
    def get_all_sorted():
        return Script.query.filter().order_by(Script.id).all()

    @staticmethod
    def get_by_config(config_id):
        query = Script.query.join(ConfigScript).join(Config).filter((ConfigScript.config_id == config_id)).all()
        return query


class ConfigScript(db.Model):
    __tablename__ = 'config_script'

    config_id = db.Column(db.String(32), ForeignKey('config.id'), primary_key=True)
    config = relationship('Config', backref=db.backref('script_association', cascade="all,delete", uselist=True))

    script_id = db.Column(db.String(32), ForeignKey('script.id'), primary_key=True)
    script = relationship('Script', backref=db.backref('config_association', cascade="all,delete", uselist=True))

    def save(self):
        db.session.add(self)
        db.session.commit()

    def remove(self):
        db.session.delete(self)
        db.session.commit()

    def as_dict(self):
        d = {'config': self.config.as_dict(),
             'script': self.script.as_dict(),
             }
        return d

    def __repr__(self):
        return '<ConfigScript {},{}>'.format(self.config_id, self.script_id)


class Run(db.Model):
    __tablename__ = 'run'

    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String(32), nullable=False)

    filename = db.Column(db.String(64), nullable=False)

    config_id = db.Column(db.String(32), ForeignKey('config.id'), nullable=False)
    config = relationship('Config', backref=db.backref('runs', cascade="all,delete", uselist=True))

    user_id = db.Column(db.String(32), ForeignKey('user.id'), nullable=False)
    user = relationship('User', backref=db.backref('runs', cascade="all,delete", uselist=True))

    script_id = db.Column(db.String(32), ForeignKey('script.id'), nullable=False)
    script = relationship('Script', backref=db.backref('runs', cascade="all,delete", uselist=True))

    status = db.Column(db.String(16), nullable=False)

    output = db.Column(db.JSON, nullable=True)

    added_date = db.Column(db.DateTime(), nullable=False)

    run_date = db.Column(db.DateTime(), nullable=True)

    comp_args = db.Column(db.String(256), nullable=True)

    run_args = db.Column(db.String(256), nullable=True)

    def save(self):
        if self.id is None:
            db.session.add(self)
        db.session.commit()

    def remove(self):
        db.session.delete(self)
        db.session.commit()

    def as_dict(self):
        d = {'id': self.id,
             'name': self.name,
             'filename': self.filename,
             'config_id': self.config_id,
             'user_id': self.user_id,
             'script_id': self.script_id,
             'status': self.status,
             'output': self.output,
             'added_date': self.added_date,
             'run_date': self.run_date,
             'comp_args': self.comp_args,
             'run_args': self.run_args
             }

        return d

    def as_dict_nest(self):
        d = self.as_dict()
        d['config'] = self.config.as_dict()
        d['user'] = self.user.as_dict()
        d['script'] = self.script.as_dict()

        return d

    def __repr__(self):
        return '<Run {}>'.format(self.id)

    @staticmethod
    def get_by_id(run_id):
        return Run.query.get(run_id)

    @staticmethod
    def get_all_sorted():
        return Run.query.filter().order_by(Run.added_date.desc()).all()

    @staticmethod
    def get_by_user_sorted(user_id):
        return Run.query.filter((Run.user_id == user_id)).order_by(Run.added_date.desc()).all()
