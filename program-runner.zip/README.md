# Program Runner

Flask based web portal that runs and analyzes program packages.


## Installation

<b>Has to be executed on LINUX!</b>

Install proyect requirements with pip:

```
$ pip install -r requirements.txt
```

Install:

- Docker engine: [Get Docker](https://docs.docker.com/get-docker/)
- Redis server: [Redis Download](https://redis.io/download)
- MYSQL Database service: [MYSQL Download](https://www.mysql.com/downloads/)

###MYSQL

Create tables statements found in <b>dev/sql_inserts</b>

Set admin user with:

<b>User:</b> ```root```

<b>Password:</b> ```root```
```
INSERT INTO user (id,email,password,admin) VALUES ('root','fake@fake.com','pbkdf2:sha256:150000$V7TpS18B$b250ac7856e84451cb19f4b4f117aeb156ee008efcc3057392c6af646efb9de9',1);
```



## Configuration

Set server configuration in <b>data/config.yml</b>

#### Example

```
#FLASK CONFIG
DEBUG: False
MAX_CONTENT_LENGTH: 16000000  # 16MB
ALLOWED_EXTENSIONS: ['zip']  #DO NOT CHANGE

#REDIS
REDIS_URL: 'redis://localhost:6379'

#MYSQL
MYSQL_USER: 'root'
MYSQL_PASS: 'root'
MYSQL_SERVER: 'localhost'
MYSQL_PORT: '3306'
MYSQL_DB: 'programrunner'
```

## Run

Flask web server:

```
python main.py
```

Worker:

```
python worker.py
```


## Extensions doc:
- Jinja2: [Flask-restplus](https://jinja.palletsprojects.com/en/3.0.x/)

- SQL ORM: [Flask-SQLalchemy](http://flask-sqlalchemy.pocoo.org/2.1/)

- Login: [Flask-login](https://flask-login.readthedocs.io/en/latest/)

- WTForms: [WTForms](https://wtforms.readthedocs.io/en/2.3.x/), [flask-wtf](https://flask-wtf.readthedocs.io/en/0.15.x/)

- Docker: [Docker-py](https://docker-py.readthedocs.io/en/stable/)

- Redis: [python-rq](https://python-rq.org/)

## Author

- Andres Cabero Mata
