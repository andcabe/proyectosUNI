if [ ! "$(docker ps -q -f name=redis_rq)" ]; then
    if [ "$(docker ps -aq -f status=exited -f name=redis_rq)" ]; then
        # Remove exited container
        docker rm redis_rq
    fi
    # Run container again
    docker run -d --name redis_rq -p 6379:6379 redis
else
  echo "Redis is running already"
fi


