import sys

from mysql.connector import MySQLConnection, InterfaceError


from redis import from_url
from redis.exceptions import ConnectionError

from runner import create_app

app = create_app()

r = from_url(app.config['REDIS_URL'], socket_connect_timeout=1)
try:
    r.ping()
except ConnectionError:
    sys.exit(f"Redis server {app.config['REDIS_URL']} unavailable. Open or set a Redis server")

try:
    cnx = MySQLConnection(user=app.config["MYSQL_USER"], password=app.config["MYSQL_PASS"],
                          host=app.config["MYSQL_SERVER"], database=app.config["MYSQL_DB"],
                          port=app.config["MYSQL_PORT"])
    if not cnx.is_connected():
        raise InterfaceError
    cnx.disconnect()
except InterfaceError:
    sys.exit(f"Mysql DB {app.config['MYSQL_DB']} in {app.config['MYSQL_SERVER']+ ':'+ app.config['MYSQL_PORT']} not available, could not start the service.")

if __name__ == '__main__':
    app.run(host=app.config["PR_SV_HOST"], port=app.config["PR_SV_PORT"])
