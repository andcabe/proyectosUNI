import sys

import redis
from mysql.connector import MySQLConnection, InterfaceError
from redis import from_url
from rq import Worker, Queue, Connection
from runner.util import io

sv_config = io.read_config()

r = from_url(sv_config['REDIS_URL'], socket_connect_timeout=1)
try:
    r.ping()
except ConnectionError:
    sys.exit(f"Redis server {sv_config['REDIS_URL']} unavailable. Open or set a Redis server")

try:
    cnx = MySQLConnection(user=sv_config["MYSQL_USER"], password=sv_config["MYSQL_PASS"],
                          host=sv_config["MYSQL_SERVER"], database=sv_config["MYSQL_DB"],
                          port=sv_config["MYSQL_PORT"])
    if not cnx.is_connected():
        raise InterfaceError
    cnx.disconnect()
except InterfaceError:
    sys.exit(
        f"Mysql DB {sv_config['MYSQL_DB']} in {sv_config['MYSQL_SERVER'] + ':' + sv_config['MYSQL_PORT']}"
        f" not available, could not start the service.")

# Connection to Redis SV
listen = ['default']
conn = redis.from_url(sv_config['REDIS_URL'])

if __name__ == '__main__':
    with Connection(conn):
        worker = Worker(list(map(Queue, listen)))
        worker.work()
