#Bash script to run a java program

## INPUT

### DOCKER ARGS/ENV VAR
#PROGRAM_ZIP="program.zip"
#PROGRAM_ROOT_PATH="./"
#PROGRAM_MAIN_PATH="main"

### OUTPUT FILES

#### VALIDATION

VALIDATION_OUTPUT="output/validation"

#### COMPILATION
COMPILATION_OUTPUT="output/compilation"

#### TESTS
TOTAL_TESTS_OUTPUT="output/total_tests"
TESTS_OUTPUT="output/tests"

#### FINAL
FINAL_OUTPUT="output/output"

## FUNCTIONS

function output_command_result_json {
    local result=$1
    local result_file=$2
    local output_file=$3
    JSON_STRING=$(jq -R -n \
                  --argjson result "$result" \
                  --arg output "$(<$result_file)" \
                  "{result: \$result, output: \$output}")
    echo "$JSON_STRING" > "$output_file"
    return 0
}


## 0 - PREPROC
rm -f -r "output"
mkdir "output"

rm -f -r "build"
mkdir "build"

## 1 - FILE AND CONFIGURATION REQUIREMENTS CHECK

function validation_json {
    local unzip=$1
    local file=$2
    local main=$3
    local validation=$4

    JSON_STRING=$(jq -R -n \
                --argjson unzip "$(<$unzip)" \
                --argjson file "$(<$file)" \
                --argjson main "$(<$main)" \
                "{unzip: \$unzip, file: \$file, main: \$main}")
    echo "$JSON_STRING" > "$validation"
    return 0
}

function validate_run_file {
    local file_path=$1
    local validation_file=$2
    local COMMAND_ERR_OUT="output/cm_output"
    local UNZIP_OUTPUT="output/unzip"
    local FILE_OUTPUT="output/file"
    local MAIN_OUTPUT="output/main"

    ### UNZIP FILE

    unzip -q -o "$file_path" -d "build/" > "$COMMAND_ERR_OUT" 2>&1
    result=$?

    output_command_result_json "$result" "$COMMAND_ERR_OUT" "$UNZIP_OUTPUT"


    ### JAVA FILE CHECK

    find  "build/" -name "*.java" | grep -q "."
    result=$?
    if [ $result -ne "0" ]; then
        echo "There is no .java file" > $COMMAND_ERR_OUT
    else
        echo "" > $COMMAND_ERR_OUT
    fi 

    output_command_result_json "$result" "$COMMAND_ERR_OUT" "$FILE_OUTPUT"


    ### MAIN FILE CHECK

    [[ -f "build/$PROGRAM_ROOT_PATH$PROGRAM_MAIN_PATH.java" ]]
    result=$?
    if [ $result -ne 0 ]; then
        echo "Main file ($PROGRAM_ROOT_PATH$PROGRAM_MAIN_PATH.java) does not exist" > $COMMAND_ERR_OUT
    else
        echo "" > $COMMAND_ERR_OUT
    fi

    output_command_result_json "$result" "$COMMAND_ERR_OUT" "$MAIN_OUTPUT"

    ### OUTPUT_JSON

    validation_json "$UNZIP_OUTPUT" "$FILE_OUTPUT" "$MAIN_OUTPUT" "$validation_file"
    rm -f "$COMMAND_ERR_OUT" "$UNZIP_OUTPUT" "$FILE_OUTPUT" "$MAIN_OUTPUT"

}

validate_run_file "$PROGRAM_ZIP" "$VALIDATION_OUTPUT"

## 2 - PROGRAM COMPILATION

function compilate_program {

    local compilation_file=$1
    local COMMAND_ERR_OUT="output/cm_output"
    find "build/" -name "*.java" > source.txt
    javac @source.txt > $COMMAND_ERR_OUT 2>&1
    result=$?
    output_command_result_json "$result" "$COMMAND_ERR_OUT" "$compilation_file"
    rm -f "$COMMAND_ERR_OUT" "source.txt"
}

compilate_program "$COMPILATION_OUTPUT"


## 3 - TEST RUNS

function test_program {

    local PROGRAM_CLASS_PATH=$1
    local PROGRAM_MAIN_PATH=$2
    local TEST_FOLDER=$3
    local TEST_RUN_FILE=$4
    local TOTAL_TEST_FILE=$5

    local TEST_NUMBER=0
    local TEST_PASSED=0

    local COMMAND_ERR_OUT="output/cm_output"

    local INPUT_FILE="input/input"
    local INPUT_DATA="input/data"
    local OUTPUT_RESULT="output/result"
    local EXPECTED_RESULT="output/expected"
    local TEST_INPUT=""
    local TEST_OUTPUT=""
    local TEST_EXPECTED=""

    local JSON_STRING="["
    for TEST in "$TEST_FOLDER"*; do

        TEST_NUMBER=$((TEST_NUMBER + 1))
        
        ### INPUT READING AND FORMATING
        
        TEST_INPUT=""
        while read -r input; do
            if echo "$input" | grep -q "^<file:"; then
                input="${input/<file::/$TEST\/$INPUT_DATA\/}"
            fi
            TEST_INPUT="$TEST_INPUT $input"
        done <"$TEST/$INPUT_FILE"

        TEST_OUTPUT="$TEST/$OUTPUT_RESULT"
        TEST_EXPECTED="$TEST/$EXPECTED_RESULT"

        ### JAVA RUN

        java -cp "$PROGRAM_CLASS_PATH" "$PROGRAM_MAIN_PATH" $TEST_INPUT $TEST_OUTPUT > $COMMAND_ERR_OUT 2>&1
        run_result=$?
        run_output="$(<$COMMAND_ERR_OUT)"

        ### OUTPUT COMPARISON

        diff -s $TEST_EXPECTED $TEST_OUTPUT > $COMMAND_ERR_OUT 2>&1
        diff_result=$?
        diff_output="$(<$COMMAND_ERR_OUT)"
        JSON_STRING+=$(jq -R -n \
            --argjson run_result "$run_result" \
            --arg run_output "$run_output" \
            --argjson test_result "$diff_result" \
            --arg test_output "$diff_output" \
            "{run_result: \$run_result, run_output: \$run_output, test_result: \$test_result, test_output: \$test_output}")','

        if [ $run_result -eq 0 ] && [ $diff_result -eq 0 ]; then
        TEST_PASSED=$((TEST_PASSED+1))
        fi

        rm -f "$TEST_OUTPUT"

    done
    JSON_STRING=${JSON_STRING::-1}
    JSON_STRING+="]"
    echo "$JSON_STRING" > "$TEST_RUN_FILE"

    ### TOTAL TEST JSON
    JSON_STRING=$(jq -R -n \
                    --argjson number "$TEST_NUMBER" \
                    --argjson passed "$TEST_PASSED" \
                    "{number: \$number, passed: \$passed}")
    echo "$JSON_STRING" > "$TOTAL_TEST_FILE"

    rm -f "$COMMAND_ERR_OUT"
    return 0
}

test_program "build/$PROGRAM_ROOT_PATH" "$PROGRAM_MAIN_PATH" "test/" "$TESTS_OUTPUT" "$TOTAL_TESTS_OUTPUT"


## 4 - FINAL OUTPUT

function total_json {
    local validation=$1
    local compilation=$2
    local total_tests=$3
    local tests=$4
    local run=$5

    JSON_STRING=$(jq -R -n \
        --argjson validation "$(<$validation)" \
        --argjson compilation "$(<$compilation)" \
        --argjson total_tests "$(<$total_tests)" \
        --argjson tests "$(<$tests)" \
        "{validation: \$validation, compilation: \$compilation, test: \$total_tests, tests: \$tests}")
    echo "$JSON_STRING" > "$run"

    return 0
}

total_json "$VALIDATION_OUTPUT" "$COMPILATION_OUTPUT" "$TOTAL_TESTS_OUTPUT" "$TESTS_OUTPUT" "$FINAL_OUTPUT"
